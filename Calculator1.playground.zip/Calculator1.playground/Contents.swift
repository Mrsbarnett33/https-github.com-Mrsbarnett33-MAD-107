import UIKit

var greeting = "Hello, playground"
/* Calculator showing addition, subtraction, multiplication and division*/

var add = 5 + 4
var substract = 5 - 4
var multiplication = 5 * 4
var division = 50 / 2

var math = 96
math += 2
math -= 2
math *= 2
math /= 2

var math2 = 100 % 3

