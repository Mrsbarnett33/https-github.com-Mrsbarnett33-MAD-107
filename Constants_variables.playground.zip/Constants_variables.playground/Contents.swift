import UIKit

var greeting = "Hello, playground"

/* Trivia Game */
let word = "Trivia"
let word2 = "Game: "
let word3 = "Each"
let word4 = "question"
let word5 = "worth"
let word6 = "100 points!"

var statement = ""
statement += "\(word) \(word2) \(word3) \(word4) \(word5) \(word6)"

/* scores for each question and calculated at end*/
var total_score = 0
var score = 0

/* scores for each question */
let q1 = 100
let q2 = 100
let q3 = 0
let q4 = 50
let q5 = 75
let q6 = 99
let q7 = 25
let q8 = 100
let q9 = 49
let q10 = 100

score += q1
total_score += score
score = 0
print(total_score)


score += q2
total_score += score
score = 0
print(total_score)


score += q3
total_score += score
score = 0
print(total_score)


score += q4
total_score += score
score = 0
print(total_score)


score += q5
total_score += score
score = 0
print(total_score)


score += q6
total_score += score
score = 0
print(total_score)


score += q7
total_score += score
score = 0
print(total_score)


score += q8
total_score += score
score = 0
print(total_score)

score += q9
total_score += score
score = 0
print(total_score)


score += q10
total_score += score
score = 0
print(total_score)


/* display final score */
var message = "The maximum points to obtain is 1000"
let final = 698
var message2 = #"You scored \#(final) out of 1000"#
print(message2)



