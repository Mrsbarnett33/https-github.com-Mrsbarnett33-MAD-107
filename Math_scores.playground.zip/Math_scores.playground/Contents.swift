import UIKit

var greeting = "Hello, playground"
/* add test scores  and find the percentage of all scores*/

var score1 = 87
var score2 = 93
var score3 = 72
var score4 = 100
var score5 = 51

score1 += score2
score3 += 180
score4 += 252
score5 += 352

var total = 403
total /= 5

